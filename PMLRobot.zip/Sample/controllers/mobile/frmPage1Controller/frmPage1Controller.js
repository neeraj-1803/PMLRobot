define({
  onNavigate: function(){
    this.view.preShow = this.frm1PreShow;
  },
  frm1PreShow: function(){
    this.view.btnSubmit.onClick = this.clickedSubmitBtn;
    this.view.txtPattern.text = "";
  },
  clickedSubmitBtn: function(){
    try{
      var txt = this.view.txtPattern.text;
      var arr = [[0,0], [1,0], [2,0], [3,0], [4,0], [5,0], [6,0], [7,0], [8,0], [9,0]];
      txt = txt.replace(/([^pmlPML]+)/gi, '').toUpperCase();
      if(txt.length >1 && txt.charAt(0) == "P"){ //checks if the command is more than one and the first one should be P, because lowering and moving wothout loading will do nothing.
        var positionBuffer = 0; //to keep track of the robot position
        var pickupBuffer = 0; //to keep track that whether the robot was loaded before Lowering or not.
        for(var i=0; i<txt.length; i++){
          if(txt.charAt(i) == "P"){
            positionBuffer = 0;
            pickupBuffer = 1;
          }
          if(txt.charAt(i) == "M"){
            if(positionBuffer != 9){
              positionBuffer++;
            }
          }
          if(txt.charAt(i) == "L"){
            var posVal = arr[positionBuffer][1];
            if(pickupBuffer == 1){
              if(posVal != "F"){//if already F that means it is full and it will be ignored.
                if(isNaN(parseInt(posVal))){ //to check if the length is A-E
                  arr[positionBuffer][1] = String.fromCharCode(posVal.charCodeAt(0)+1);
                }else{
                  if(posVal == 9){//if length is 9 then it should be updated to A
                    arr[positionBuffer][1] = "A";
                  }else{
                    arr[positionBuffer][1] = posVal+1;
                  }
                }
                pickupBuffer = 0;
                positionBuffer = 0;
              }
            }
          }
        }
        var nav = new kony.mvc.Navigation("frmPage2");
        nav.navigate(arr);
      }else{
        alert("Please enter valid values..");
      }
    }catch(e){
      kony.print("Error in clickedSubmitBtn function-->"+e);
    }
  }
});
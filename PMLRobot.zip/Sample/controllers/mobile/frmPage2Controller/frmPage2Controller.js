define({ 
  onNavigate: function(data){
    this.view.preShow = this.frm2PreShow.bind(this, data);
  },
  frm2PreShow: function(data){
    try{
      this.view.HeaderPML.headerButtonLeft.onClick = this.goBack;
      var segData = [];
      for(var i=0; i<data.length; i++){
        var rowData = {};
        var rowName = data[i][0].toFixed(0);
        var rowCount = data[i][1];
        if(!isNaN(parseInt(rowCount))){
          rowCount = rowCount.toFixed(0);//to convert to integer value
        }
        rowData.lblRowName = {
          "text": rowName
        };
        rowData.lblRowCount = {
          "text": rowCount
        };
        segData.push(rowData);
      }
      this.view.segCounter.removeAll();
      var segmntData = [[{"lblHeadingRowName": "Row Name","lblHeadingRowCount": "Row Count"},segData]];
      this.view.segCounter.setData(segmntData);
    }catch(e){
      this.view.segCounter.removeAll();
      kony.print("Error in frmPage2 preshow-->"+e);
    }
  },
  goBack: function(){
    new kony.mvc.Navigation("frmPage1").navigate();
  }
});